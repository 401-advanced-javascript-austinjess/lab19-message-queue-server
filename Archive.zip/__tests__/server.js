describe('The Logger', () => {
  it('should be aware', () => {
    expect();
  });
});
